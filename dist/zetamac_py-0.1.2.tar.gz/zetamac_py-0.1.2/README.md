# zetamac-py

TUI zetamac clone (identical core interface) plus SQLite tracking, replay, and flash anzan (also mental arithmetic), built with [Textual](https://github.com/Textualize/textual).

![Python](https://img.shields.io/badge/python-3.10%2B-blue)
![Textual](https://img.shields.io/badge/built%20with-Textual-magenta)
![License](https://img.shields.io/badge/license-GPLv3-green)

## Screenshots

<!-- https://raw.githubusercontent.com/yaofanfish/zetamac-py/refs/heads/main -->
![Settings](https://raw.githubusercontent.com/yaofanfish/zetamac-py/refs/heads/main/assets/63dd43f7-3f04-4e29-a218-b13fdf09415e.png)
![Play](https://raw.githubusercontent.com/yaofanfish/zetamac-py/refs/heads/main/assets/16c844ea-70ce-4e1a-9d76-011f095fc959.png)
![View runs](https://raw.githubusercontent.com/yaofanfish/zetamac-py/refs/heads/main/assets/c63567db-c70a-4e45-a05c-efcdf6736680.png)

## Features

* **All features** from arithmetic.zetamac.com with an identical interface and functionality (as shown above), like addition, subtraction, division. 
* Local SQLite run history with per-problem timings (only runs with default setting though, otherwise everything gets jumbled and you can't track data effectively)
* A pretty interface for selecting runs with summaries for each
* Able to replay any run, or replay all the hardest questions (questions which took the longest time)
* Per-run analytics to identify weak spots
* Fully keyboard-driven terminal UI (what Textual does). 

* An additional flash anzan gamemode, although that doesn't have the logging the core does

* Written in python, so can descend into a python or sqlite shell for directly interacting with the state. For dev, and can be normally used with helper functions defined. 

## Installation

Requires Python 3.10+.

```bash
git clone https://github.com/yaofanfish/zetamac-py.git
cd zetamac-py
pipx install -e .[opt]
```
(or use pip, if you have all your venvs set up correctly)

## Usage

```bash
zetamac-py
```
The interface is generally straightforward, and as mentioned before, the core is identical to the web zetamac. 
Configure settings, start a round, review past runs, or replay difficult questions directly from the menu.

## Data Storage

(
	On windows, replace ~ with %USERPROFILE%\AppData\Local\zetamac-py, so settings would be C:\Users\DemoUser\AppData\Local\zetamac-py\.local\state\zetamac-py\settings.json
	It is linux first, so the paths are a bit awkward. 
)

* Settings: `~/.local/state/zetamac-py/settings.json`
* Run history: `~/.local/share/zetamac-py/runs.db`
* Python rc file: `~/.config/zetamac-py/pyrc.py`

## Contributing

Issues and pull requests are welcome.

```bash
git clone https://github.com/yaofanfish/zetamac-py.git
cd zetamac-py
pip install -e ".[dev,opt]"
```

## License

GPL-3.0

## Acknowledgments

Inspired by [Zetamac](https://arithmetic.zetamac.com/) by Zach Wissner-Gross.

