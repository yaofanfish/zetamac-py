Actual stats

