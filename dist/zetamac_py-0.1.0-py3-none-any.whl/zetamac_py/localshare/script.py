import sqlite3

# Connect to the database
conn = sqlite3.connect('runs.db')
cursor = conn.cursor()

try:
    # 1. Fetch the data from the very last row
    # (We exclude 'id' from the SELECT so SQLite auto-increments it on insertion)
    cursor.execute("SELECT score, ts, logs FROM runs ORDER BY id DESC LIMIT 1;")
    last_row = cursor.fetchone()

    if last_row:
        # 2. Prepare the 64 duplicate rows
        # last_row is a tuple like (score, ts, logs)
        rows_to_insert = [last_row] * 64

        # 3. Bulk insert them efficiently
        cursor.executemany(
            "INSERT INTO runs (score, ts, logs) VALUES (?, ?, ?);", 
            rows_to_insert
        )
        
        # Commit the changes to the database
        conn.commit()
        print(f"Successfully cloned the last row 64 times.")
    else:
        print("The 'runs' table is currently empty. Nothing to clone.")

except sqlite3.Error as e:
    print(f"An error occurred: {e}")
    conn.rollback()

finally:
    # Always close the connection
    conn.close()

